public class Flags {
    Boolean flagEnd;

    public Flags(){
        flagEnd = false;
    }

    public Boolean getFlagEnd() {
        return flagEnd;
    }

    public void setFlagEnd(boolean b){
        flagEnd = b;
    }

}
